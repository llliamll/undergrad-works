/*
 * template.c
 *
 * An OpenGL source code template.
 */


#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/freeglut_ext.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include "../mylib/initShader.h"
#include "../mylib/matrix.h"


#define BUFFER_OFFSET( offset )   ((GLvoid*) (offset))

GLuint ctm_location;
mat4 ctm = {
        {1,0,0,0},
        {0,1,0,0},
        {0,0,1,0},
        {0,0,0,1}
};
float zoom_value = 0;
int zoom = 1;
int num_vertices = 180;
void generate_wall(vec4 vertices[])
{
    //copy the outer coordinates
    vec4 temp[90];
    for(int i=0; i<90; i++){
        temp[i].x = vertices[i].x;
        temp[i].y = vertices[i].y;
        temp[i].z = vertices[i].z;
        temp[i].w = vertices[i].w;
    }
    for(int i=0; i<90; i++){
        vertices[i+90].x=temp[i].x;
        vertices[i+90].y=temp[i].y;
        vertices[i+90].z=temp[i].z;
        vertices[i+90].w=temp[i].w;
    }
    for(int i=90; i<180; i+=3){
        vertices[i].x=0;
        vertices[i].y=0.5;
        vertices[i].z=0;
        vertices[i].w=1;
    }

}
void generate_vertices(vec4 vertices[])
{
    int   triangle_num  = 30;
    float angle         = 3.1415926 * 2.f / triangle_num;
    float radius        = 0.3;

    //first 60 vertices to generate the bottom
    for(int i=0; i<90; i++){
        if(i==0 || i%3==0){
            vertices[i].x=0.0; vertices[i].y=-0.5;
            vertices[i].z=0.0; vertices[i].w=1.0;
            continue;
        }
        vertices[i].x=radius*cosf(angle+i);
        vertices[i].y=-0.5;
        vertices[i].z=-radius*sinf(angle+i);
        vertices[i].w=1;
    }
    //second 60 vertices to generate the wall
    generate_wall(vertices);
}
void generate_color(vec4 colors[])
{
    srand(time(0));
    for(int i = 0; i < 180; i+=3){
        float randx = (float) rand()/ (float) RAND_MAX;
        float randy = (float) rand()/ (float) RAND_MAX;
        float randz = (float) rand()/ (float) RAND_MAX;



        colors[i].x   = randx; colors[i].y   = randy; colors[i].z   = randz; colors[i].w   = 1;
        colors[i+1].x = randx; colors[i+1].y = randy; colors[i+1].z = randz; colors[i+1].w = 1;
        colors[i+2].x = randx; colors[i+2].y = randy; colors[i+2].z = randz; colors[i+2].w = 1;
    }
}

void init(void)
{
    GLuint program = initShader("vshader.glsl", "fshader.glsl");
    glUseProgram(program);

    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    vec4 vertices[180];
    generate_vertices(vertices);
    vec4 colors[180];
    generate_color(colors);

    GLuint buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices) + sizeof(colors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(vertices), sizeof(colors), colors);

    GLuint vPosition = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint vColor = glGetAttribLocation(program, "vColor");
    glEnableVertexAttribArray(vColor);
    glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, (GLvoid *) sizeof(vertices));

    ctm_location = glGetUniformLocation(program,"ctm");

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glDepthRange(1,0);
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPolygonMode(GL_FRONT, GL_FILL);
    glPolygonMode(GL_BACK, GL_LINE);

    glUniformMatrix4fv(ctm_location, 1, GL_FALSE, (GLfloat *) &ctm);

    glDrawArrays(GL_TRIANGLES, 0, num_vertices);

    glutSwapBuffers();
}

void keyboard(unsigned char key, int mousex, int mousey)
{
    if(key == 'q')
    	glutLeaveMainLoop();

    //glutPostRedisplay();
}

void reshape(int width, int height)
{
    glViewport(0, 0, 512, 512);
}

void idle(void)
{
    if(zoom){
        zoom_value += 0.01;
        if(zoom_value>2.0){
            zoom_value = 2.0;
            zoom = 0;
        }
    }else{
        zoom_value -= 0.01;
        if(zoom_value<-2.0){
            zoom_value = -2.0;
            zoom = 1;
        }
    }

    //ctm = translation_matrix(x_value,x_value,0.0);
    ctm = rotating_mat_y(zoom_value);
    glutPostRedisplay();
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(512, 512);
    glutInitWindowPosition(100,100);
    glutCreateWindow("lab04");
    glewInit();
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutReshapeFunc(reshape);
    glutIdleFunc(idle);
    glutMainLoop();

    return 0;
}
